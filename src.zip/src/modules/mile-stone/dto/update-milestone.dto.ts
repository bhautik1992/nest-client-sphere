import { CreateMileStoneDto } from "./create-milestone.dto";

export class UpdateMileStoneDto extends CreateMileStoneDto {}
