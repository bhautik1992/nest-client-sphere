import { CreateCrDto } from "./create-cr.dto";

export class UpdateCrDto extends CreateCrDto {}
